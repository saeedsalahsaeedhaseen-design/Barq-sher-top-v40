package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.DeviceMediaRepository
import com.example.data.InstalledAppsRepository
import com.example.model.ChunkSizeOption
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.TransferFileItem
import com.example.network.P2PChunkServer
import com.example.util.Sha256Util
import com.example.viewmodel.P2PTransferViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun verifyAppNameAndBranding() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("برق sher", appName)
        composeTestRule.onAllNodesWithText("برق sher", substring = true).onFirst().assertIsDisplayed()
        composeTestRule.onAllNodesWithText("جميع الحقوق محفوظة © saeed", substring = true).onFirst().assertIsDisplayed()
    }

    @Test
    fun verifyAllNineNavigationTabsAndSendFolderButtons() {
        val navTabs = listOf(
            "bottom_nav_HOME",
            "bottom_nav_APPS",
            "bottom_nav_IMAGES",
            "bottom_nav_VIDEOS",
            "bottom_nav_AUDIO",
            "bottom_nav_FILES",
            "bottom_nav_SEND",
            "bottom_nav_RECEIVE",
            "bottom_nav_HISTORY"
        )

        // Verify Home screen has dedicated "إرسال مجلد كامل" button
        composeTestRule.onNodeWithTag("home_send_entire_folder_button").assertExists()

        // Verify all 9 tabs exist in the scrollable bottom navigation bar and test navigating through them
        for (tag in navTabs) {
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag(tag))
            composeTestRule.onNodeWithTag(tag).assertExists()

            if (tag == "bottom_nav_APPS") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("refresh_installed_apps_button").assertExists()
            } else if (tag == "bottom_nav_SEND") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("send_pick_entire_folder_button")
                    .performScrollTo()
                    .assertExists()
                composeTestRule.onNodeWithTag("start_live_sending_button")
                    .performScrollTo()
                    .performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithText(
                    "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال",
                    substring = true
                ).assertExists()
            }
        }
    }

    @Test
    fun verifyInstalledAppsRepositoryReadsPackageManager() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val apps = InstalledAppsRepository.loadInstalledSharableApps(context, includeSystemApps = true)
        assertNotNull(apps)
    }

    @Test
    fun verifyRealMultiFileChunkedTransferAndSha256Integrity() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "p2p_real_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempDir, "received").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Create 4 real files representing Image, Audio, Document, and multi-chunk APK
            val imgFile = File(tempDir, "camera_photo.jpg").apply {
                writeBytes(Random(42).nextBytes(24_500))
            }
            val audioFile = File(tempDir, "voice_track.mp3").apply {
                writeBytes(Random(43).nextBytes(48_200))
            }
            val docFile = File(tempDir, "project_spec.pdf").apply {
                writeBytes("%PDF-1.7 Real Document Content ".repeat(800).toByteArray())
            }
            // 180 KB APK file -> 3 chunks when using 64 KB chunk size
            val apkFile = File(tempDir, "base_release.apk").apply {
                writeBytes(Random(44).nextBytes(180 * 1024 + 321))
            }

            val chunkOption = ChunkSizeOption.CHUNK_64KB
            val chunkSizeBytes = chunkOption.bytes.toLong()
            val sourceFiles = listOf(
                Pair(imgFile, FileCategory.IMAGE),
                Pair(audioFile, FileCategory.AUDIO),
                Pair(docFile, FileCategory.DOCUMENT),
                Pair(apkFile, FileCategory.GAME_APK)
            )

            val transferItems = sourceFiles.mapIndexed { idx, (file, cat) ->
                val sha = Sha256Util.computeFileSha256(file)
                assertTrue("SHA-256 should be 64 hex chars", sha.length == 64)
                val totalChunks = ((file.length() + chunkSizeBytes - 1) / chunkSizeBytes).toInt()
                TransferFileItem(
                    id = "test_item_$idx",
                    name = file.name,
                    sizeBytes = file.length(),
                    category = cat,
                    localFile = file,
                    totalChunks = totalChunks,
                    completedChunks = 0,
                    sha256Expected = sha
                )
            }

            var isSenderReady = false
            val sessionCode = "BRQ-7788"

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { isSenderReady },
                chunkSizeProvider = { chunkOption },
                filesProvider = { transferItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                // Wait briefly for server socket to bind
                Thread.sleep(100)

                // 1. Verify /api/manifest rejects connection when sender is NOT ready (HTTP 403)
                val unreadyConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(403, unreadyConn.responseCode)
                unreadyConn.disconnect()

                // 2. Activate Sender Ready state, verify wrong code is still rejected (HTTP 403)
                isSenderReady = true
                val wrongCodeConn = (URL("http://127.0.0.1:$port/api/manifest?code=BRQ-0000").openConnection() as HttpURLConnection)
                assertEquals(403, wrongCodeConn.responseCode)
                wrongCodeConn.disconnect()

                // 3. Connect with valid session code and parse manifest
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestBody = manifestConn.inputStream.bufferedReader().use { it.readText() }
                manifestConn.disconnect()

                val json = JSONObject(manifestBody)
                assertEquals(sessionCode, json.getString("sessionCode"))
                val filesArray = json.getJSONArray("files")
                assertEquals(4, filesArray.length())

                // 4. Download all 4 files chunk-by-chunk (including resumable RandomAccessFile writes)
                for (i in 0 until filesArray.length()) {
                    val fObj = filesArray.getJSONObject(i)
                    val fileId = fObj.getString("id")
                    val fileName = fObj.getString("name")
                    val expectedSize = fObj.getLong("sizeBytes")
                    val expectedSha256 = fObj.getString("sha256")
                    val totalChunks = fObj.getInt("totalChunks")

                    val partFile = File(receiveDir, "$fileName.part")
                    val finalFile = File(receiveDir, fileName)

                    for (chunkIdx in 0 until totalChunks) {
                        val chunkUrl = "http://127.0.0.1:$port/api/chunk?code=$sessionCode&fileId=$fileId&chunkIndex=$chunkIdx&chunkSize=$chunkSizeBytes"
                        val chunkConn = (URL(chunkUrl).openConnection() as HttpURLConnection)
                        assertEquals(200, chunkConn.responseCode)
                        val bytes = chunkConn.inputStream.use { it.readBytes() }
                        chunkConn.disconnect()

                        // Write chunk at exact offset using RandomAccessFile (same mechanism used for Pause/Resume)
                        RandomAccessFile(partFile, "rw").use { raf ->
                            raf.seek(chunkIdx.toLong() * chunkSizeBytes)
                            raf.write(bytes)
                        }
                    }

                    assertTrue(partFile.renameTo(finalFile))
                    assertEquals("File size must match 100% for $fileName", expectedSize, finalFile.length())
                    val actualSha256 = Sha256Util.computeFileSha256(finalFile)
                    assertEquals("SHA-256 must match 100% for $fileName", expectedSha256, actualSha256)
                    assertFalse(partFile.exists())
                }
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun verifyWholeFolderRecursiveTransferWithEmptyDirsAndDuplicateHandling() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "folder_tree_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val sourceRootFolder = File(tempRoot, "BarqProjectFolder").apply { mkdirs() }
        val receiveBaseDir = File(tempRoot, "Downloads_BarqSher").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Build a multi-level folder structure:
            // BarqProjectFolder/
            //   README.md (3 KB)
            //   empty_note.txt (0 bytes)
            //   EmptySubFolder/ (empty directory)
            //   assets/
            //     banner.png (95 KB)
            //     nested_empty/ (empty directory)
            //     videos/
            //       intro_clip.mp4 (420 KB)
            val readmeBytes = "# Barq Sher Whole Folder Transfer\n".repeat(90).toByteArray()
            val bannerBytes = Random(101).nextBytes(95 * 1024 + 17)
            val videoBytes = Random(202).nextBytes(420 * 1024 + 513)

            File(sourceRootFolder, "README.md").writeBytes(readmeBytes)
            File(sourceRootFolder, "empty_note.txt").writeBytes(ByteArray(0))
            File(sourceRootFolder, "EmptySubFolder").mkdirs()

            val assetsDir = File(sourceRootFolder, "assets").apply { mkdirs() }
            File(assetsDir, "banner.png").writeBytes(bannerBytes)
            File(assetsDir, "nested_empty").mkdirs()

            val videosDir = File(assetsDir, "videos").apply { mkdirs() }
            File(videosDir, "intro_clip.mp4").writeBytes(videoBytes)

            val chunkOption = ChunkSizeOption.CHUNK_256KB
            val scanResult = DeviceMediaRepository.scanLocalFolderForTransfer(
                rootDir = sourceRootFolder,
                chunkSizeBytes = chunkOption.bytes
            )

            assertNullOrEmptyError(scanResult.errorMessage)
            val batchInfo = scanResult.batchInfo
            assertNotNull("FolderBatchInfo must not be null", batchInfo)
            assertEquals("BarqProjectFolder", batchInfo!!.rootFolderName)
            assertEquals("Should detect 4 files (including 0-byte file)", 4, batchInfo.totalFilesCount)
            assertEquals("Should detect 2 empty folders", 2, batchInfo.emptyFoldersCount)
            assertEquals("Total items (4 files + 2 empty folders) = 6", 6, scanResult.transferItems.size)

            // Compute expected SHA-256 for each item (just as startLiveChunkedTransfer does)
            val preparedItems = scanResult.transferItems.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-9100"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { chunkOption },
                filesProvider = { preparedItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // Verify manifest contains relativePath, rootFolderName, and isDirectory
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestJson = JSONObject(manifestConn.inputStream.bufferedReader().use { it.readText() })
                manifestConn.disconnect()

                val manifestFiles = manifestJson.getJSONArray("files")
                assertEquals(6, manifestFiles.length())

                // Receive Session #1: Recreate folder structure inside receiveBaseDir/BarqProjectFolder/...
                val completedSession1 = mutableListOf<TransferFileItem>()
                val failedSession1 = mutableListOf<String>()
                var currentItems1 = preparedItems
                val anyFailed1 = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = chunkOption.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { currentItems1 },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedSession1) {
                            currentItems1 = currentItems1.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedSession1) { completedSession1.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(failedSession1) { failedSession1.add(err) }
                    }
                )

                assertFalse("All items in session 1 must succeed without failure: $failedSession1", anyFailed1)
                assertEquals(0, failedSession1.size)
                assertEquals(6, completedSession1.size)
                assertTrue(completedSession1.all { it.status == FileTransferStatus.COMPLETED && it.sha256Verified })

                // Verify recreated directory tree on receiver
                val recreatedRoot1 = File(receiveBaseDir, "BarqProjectFolder")
                assertTrue("Root folder must exist", recreatedRoot1.exists() && recreatedRoot1.isDirectory)
                assertTrue("EmptySubFolder must be recreated", File(recreatedRoot1, "EmptySubFolder").isDirectory)
                assertTrue("assets/nested_empty must be recreated", File(recreatedRoot1, "assets/nested_empty").isDirectory)

                val receivedReadme = File(recreatedRoot1, "README.md")
                val receivedEmptyNote = File(recreatedRoot1, "empty_note.txt")
                val receivedBanner = File(recreatedRoot1, "assets/banner.png")
                val receivedVideo = File(recreatedRoot1, "assets/videos/intro_clip.mp4")

                assertTrue(receivedReadme.exists() && receivedReadme.readBytes().contentEquals(readmeBytes))
                assertTrue(receivedEmptyNote.exists() && receivedEmptyNote.length() == 0L)
                assertTrue(receivedBanner.exists() && receivedBanner.readBytes().contentEquals(bannerBytes))
                assertTrue(receivedVideo.exists() && receivedVideo.readBytes().contentEquals(videoBytes))

                // Receive Session #2 into the SAME downloadDir -> Must deduplicate root folder as "BarqProjectFolder (1)"
                val completedSession2 = mutableListOf<TransferFileItem>()
                var currentItems2 = preparedItems
                val anyFailed2 = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = chunkOption.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { currentItems2 },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedSession2) {
                            currentItems2 = currentItems2.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedSession2) { completedSession2.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                assertFalse(anyFailed2)
                assertEquals(6, completedSession2.size)

                val recreatedRoot2 = File(receiveBaseDir, "BarqProjectFolder (1)")
                assertTrue("Duplicate root folder must be created as 'BarqProjectFolder (1)'", recreatedRoot2.exists() && recreatedRoot2.isDirectory)
                assertTrue(File(recreatedRoot2, "EmptySubFolder").isDirectory)
                assertTrue(File(recreatedRoot2, "assets/videos/intro_clip.mp4").readBytes().contentEquals(videoBytes))
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun benchmarkTransferSpeedBeforeVsAfterOptimization() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val benchRoot = File(context.cacheDir, "speed_bench_${System.currentTimeMillis()}").apply { mkdirs() }
        val legacyOutDir = File(benchRoot, "legacy_out").apply { mkdirs() }
        val optimizedOutDir = File(benchRoot, "optimized_out").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Prepare a realistic mixed dataset:
            // - 1 large binary file (12 MB)
            // - 24 small/medium files inside a folder (total ~3 MB)
            // Total payload = ~15 MB
            val largeFileBytes = Random(555).nextBytes(12 * 1024 * 1024)
            val largeFile = File(benchRoot, "game_update_bundle.apk").apply {
                writeBytes(largeFileBytes)
            }
            val largeSha = Sha256Util.computeFileSha256(largeFile)

            val smallFiles = (1..24).map { idx ->
                val bytes = Random(1000 + idx).nextBytes(128 * 1024) // 128 KB each
                val f = File(benchRoot, "photo_$idx.jpg").apply { writeBytes(bytes) }
                Pair(f, Sha256Util.computeFileSha256(f))
            }

            val allItemsForLegacy = mutableListOf<TransferFileItem>()
            val legacyChunkSize = ChunkSizeOption.CHUNK_256KB.bytes
            allItemsForLegacy.add(
                TransferFileItem(
                    id = "bench_large",
                    name = largeFile.name,
                    sizeBytes = largeFile.length(),
                    category = FileCategory.GAME_APK,
                    localFile = largeFile,
                    totalChunks = ((largeFile.length() + legacyChunkSize - 1) / legacyChunkSize).toInt(),
                    completedChunks = 0,
                    sha256Expected = largeSha
                )
            )
            smallFiles.forEachIndexed { idx, (f, sha) ->
                allItemsForLegacy.add(
                    TransferFileItem(
                        id = "bench_small_$idx",
                        name = f.name,
                        relativePath = "Album/${f.name}",
                        rootFolderName = "Album",
                        sizeBytes = f.length(),
                        category = FileCategory.IMAGE,
                        localFile = f,
                        totalChunks = 1,
                        completedChunks = 0,
                        sha256Expected = sha
                    )
                )
            }

            val totalPayloadBytes = allItemsForLegacy.sumOf { it.sizeBytes }
            val sessionCode = "BRQ-5500"

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.AUTO_MAX },
                filesProvider = { allItemsForLegacy },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // =========================================================================
                // 1. BEFORE OPTIMIZATION (Legacy Approach):
                //    - Sequential file-by-file, chunk-by-chunk HTTP requests with Connection: close
                //    - Unbuffered 8 KB RandomAccessFile writes on every socket read
                //    - Second full-file disk read at the end to compute SHA-256
                // =========================================================================
                val legacyStartNano = System.nanoTime()
                for (item in allItemsForLegacy) {
                    val destFile = File(legacyOutDir, item.name)
                    val partFile = File(legacyOutDir, "${item.name}.part")
                    val totalChunks = max(1, ((item.sizeBytes + legacyChunkSize - 1) / legacyChunkSize).toInt())
                    for (cIdx in 0 until totalChunks) {
                        val url = URL("http://127.0.0.1:$port/api/chunk?code=$sessionCode&fileId=${item.id}&chunkIndex=$cIdx&chunkSize=$legacyChunkSize")
                        val conn = (url.openConnection() as HttpURLConnection).apply {
                            setRequestProperty("Connection", "close")
                        }
                        assertEquals(200, conn.responseCode)
                        RandomAccessFile(partFile, "rw").use { raf ->
                            raf.seek(cIdx.toLong() * legacyChunkSize)
                            val buf = ByteArray(8192)
                            conn.inputStream.use { input ->
                                while (true) {
                                    val r = input.read(buf)
                                    if (r <= 0) break
                                    raf.write(buf, 0, r)
                                }
                            }
                        }
                        conn.disconnect()
                    }
                    partFile.renameTo(destFile)
                    // Second pass disk read for SHA-256 (as old code did)
                    val sha = Sha256Util.computeFileSha256(destFile)
                    assertEquals(item.sha256Expected, sha)
                }
                val legacyElapsedSec = max(0.001, (System.nanoTime() - legacyStartNano) / 1_000_000_000.0)
                val legacySpeedMBps = (totalPayloadBytes / 1_000_000.0) / legacyElapsedSec
                val legacySpeedMiBps = (totalPayloadBytes / (1024.0 * 1024.0)) / legacyElapsedSec

                // =========================================================================
                // 2. AFTER OPTIMIZATION (New High-Speed Streaming Engine):
                //    - HTTP/1.1 Keep-Alive connection reuse + /api/stream continuous streaming
                //    - 256 KB write coalescing buffer
                //    - On-the-fly SHA-256 calculation during network read (zero extra disk read)
                //    - 3-worker bounded concurrency for small/medium files
                // =========================================================================
                val optCompleted = mutableListOf<TransferFileItem>()
                var optItemsState = allItemsForLegacy.toList()
                val optStartNano = System.nanoTime()
                val optAnyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.AUTO_MAX.bytes,
                    downloadDir = optimizedOutDir,
                    itemsProvider = { optItemsState },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(optCompleted) {
                            optItemsState = optItemsState.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(optCompleted) { optCompleted.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                val optElapsedSec = max(0.001, (System.nanoTime() - optStartNano) / 1_000_000_000.0)
                val optSpeedMBps = (totalPayloadBytes / 1_000_000.0) / optElapsedSec
                val optSpeedMiBps = (totalPayloadBytes / (1024.0 * 1024.0)) / optElapsedSec

                assertFalse(optAnyFailed)
                assertEquals(allItemsForLegacy.size, optCompleted.size)

                println(
                    String.format(
                        Locale.US,
                        "BENCHMARK_RESULT|Payload=%.2f MB|Legacy=%.2f MB/s (%.2f MiB/s) in %.3fs|Optimized=%.2f MB/s (%.2f MiB/s) in %.3fs|Speedup=%.2fx",
                        totalPayloadBytes / 1_000_000.0,
                        legacySpeedMBps,
                        legacySpeedMiBps,
                        legacyElapsedSec,
                        optSpeedMBps,
                        optSpeedMiBps,
                        optElapsedSec,
                        optSpeedMBps / max(0.1, legacySpeedMBps)
                    )
                )

                assertTrue("Optimized transfer should succeed with positive throughput", optSpeedMBps > 0.0)
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            benchRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyInAppFolderAndFileMultiSelectionAndHierarchyTransfer() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        ).apply { mkdirs() }

        // Create "Download/ropon" with files, nested subfolders, and an empty subfolder
        val roponDir = File(downloadRoot, "ropon").apply {
            deleteRecursively()
            mkdirs()
        }
        val projectDocsDir = File(downloadRoot, "project_docs").apply {
            deleteRecursively()
            mkdirs()
        }
        val standaloneFile = File(downloadRoot, "standalone_note.txt")
        val receiveBaseDir = File(context.cacheDir, "received_multi_folder_${System.currentTimeMillis()}").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            val roponMainBytes = "Ropon Main Configuration File\n".repeat(40).toByteArray()
            val roponLevelBytes = Random(777).nextBytes(64 * 1024 + 19)
            val docsSpecBytes = "Project Architecture Specification v2\n".repeat(50).toByteArray()
            val standaloneBytes = "Standalone file selected alongside folders!".toByteArray()

            File(roponDir, "config.json").writeBytes(roponMainBytes)
            val roponLevelsSub = File(roponDir, "levels/world1").apply { mkdirs() }
            File(roponLevelsSub, "map_data.bin").writeBytes(roponLevelBytes)
            File(roponDir, "empty_cache").mkdirs()

            File(projectDocsDir, "architecture.md").writeBytes(docsSpecBytes)
            standaloneFile.writeBytes(standaloneBytes)

            // 1. Load general files and folders via DeviceMediaRepository
            val (loadedFiles, loadedFolders) = DeviceMediaRepository.loadGeneralFilesAndFolders(context)

            val roponFolderItem = loadedFolders.find {
                it.name == "ropon" || it.relativeDisplayPath.equals("Download/ropon", ignoreCase = true)
            }
            val docsFolderItem = loadedFolders.find {
                it.name == "project_docs" || it.relativeDisplayPath.equals("Download/project_docs", ignoreCase = true)
            }
            val standaloneMediaItem = loadedFiles.find { it.name == "standalone_note.txt" }

            assertNotNull("Download/ropon must be discovered as a selectable folder in the list", roponFolderItem)
            assertNotNull("Download/project_docs must be discovered as a selectable folder in the list", docsFolderItem)
            assertNotNull("standalone_note.txt must be discovered in the files list", standaloneMediaItem)

            assertEquals("ropon should report 2 files", 2, roponFolderItem!!.fileCount)
            assertTrue("ropon should report at least 1 empty subfolder", roponFolderItem.emptySubfolderCount >= 1)
            assertEquals(
                "ropon totalBytes should match sum of its files",
                (roponMainBytes.size + roponLevelBytes.size).toLong(),
                roponFolderItem.totalBytes
            )

            // 2. Test ViewModel multi-selection of multiple folders + standalone file together
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            vm.loadAllDeviceMediaAndFiles()
            // Wait until repository finishes loading into ViewModel state
            val deadline = System.currentTimeMillis() + 5_000L
            while (System.currentTimeMillis() < deadline &&
                vm.uiState.value.storageFolders.none { it.path == roponFolderItem.path }
            ) {
                Thread.sleep(50)
            }

            vm.clearAllManagerSelections()
            // Select folder 1 ("Download/ropon"), folder 2 ("Download/project_docs"), and 1 standalone file
            vm.toggleFolderSelection(roponFolderItem.path)
            vm.toggleFolderSelection(docsFolderItem!!.path)
            vm.toggleMediaSelection(standaloneMediaItem!!.id)

            val stateAfterSelection = vm.uiState.value
            assertEquals("2 folders must be selected", 2, stateAfterSelection.selectedFoldersCount)
            assertEquals("1 standalone file must be selected", 1, stateAfterSelection.selectedFilesAndAppsCount)
            assertEquals("Total selected count in manager must be 3", 3, stateAfterSelection.totalSelectedCountInManager)

            val expectedTotalBytes = roponMainBytes.size.toLong() +
                roponLevelBytes.size.toLong() +
                docsSpecBytes.size.toLong() +
                standaloneBytes.size.toLong()
            assertEquals(
                "Total selected bytes must equal sum of both folders + standalone file",
                expectedTotalBytes,
                stateAfterSelection.totalSelectedBytesInManager
            )

            // 3. Press "إرسال المحدد" -> Add selected folders & files to send queue
            vm.addManagerSelectionsToSendQueueAndGoToSend()
            val sendQueueDeadline = System.currentTimeMillis() + 5_000L
            while (System.currentTimeMillis() < sendQueueDeadline &&
                vm.uiState.value.currentScreen != com.example.model.AppScreen.SEND
            ) {
                Thread.sleep(50)
            }

            val sendState = vm.uiState.value
            assertEquals(com.example.model.AppScreen.SEND, sendState.currentScreen)
            assertEquals("Each selected folder must be added as a unified FolderBatchInfo", 2, sendState.folderBatches.size)
            assertEquals("Standalone file must be in standaloneFilesInQueue", 1, sendState.standaloneFilesInQueue.size)
            assertEquals("Total transfer units in send queue must be 3 (2 folders + 1 file)", 3, sendState.totalSelectedUnitsInSendQueue)

            // 4. Verify end-to-end transfer recreates root folders ("ropon" and "project_docs") first on receiver
            val preparedQueueItems = sendState.files.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-4040"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { preparedQueueItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var receiverItems = preparedQueueItems
                val completedItems = mutableListOf<TransferFileItem>()
                val failedErrors = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedItems) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedItems) { completedItems.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(failedErrors) { failedErrors.add(err) }
                    }
                )

                assertFalse("Transfer must succeed with zero errors: $failedErrors", anyFailed)
                assertEquals(preparedQueueItems.size, completedItems.size)

                // Verify receiver created "ropon" and "project_docs" root folders and placed contents inside
                val receivedRoponRoot = File(receiveBaseDir, "ropon")
                assertTrue("Receiver must create root folder 'ropon'", receivedRoponRoot.isDirectory)
                assertTrue(
                    "ropon/config.json must match bytes",
                    File(receivedRoponRoot, "config.json").readBytes().contentEquals(roponMainBytes)
                )
                assertTrue(
                    "ropon/levels/world1/map_data.bin must match bytes",
                    File(receivedRoponRoot, "levels/world1/map_data.bin").readBytes().contentEquals(roponLevelBytes)
                )
                assertTrue(
                    "ropon/empty_cache empty subfolder must be created",
                    File(receivedRoponRoot, "empty_cache").isDirectory
                )

                val receivedDocsRoot = File(receiveBaseDir, "project_docs")
                assertTrue("Receiver must create root folder 'project_docs'", receivedDocsRoot.isDirectory)
                assertTrue(
                    "project_docs/architecture.md must match bytes",
                    File(receivedDocsRoot, "architecture.md").readBytes().contentEquals(docsSpecBytes)
                )

                val receivedStandalone = File(receiveBaseDir, "standalone_note.txt")
                assertTrue(
                    "Standalone file must be saved in receiveBaseDir alongside folders",
                    receivedStandalone.exists() && receivedStandalone.readBytes().contentEquals(standaloneBytes)
                )
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            roponDir.deleteRecursively()
            projectDocsDir.deleteRecursively()
            standaloneFile.delete()
            receiveBaseDir.deleteRecursively()
        }
    }

    @Test
    fun verifyHierarchicalFolderBrowsingAndSessionApprovalHandshake() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        @Suppress("DEPRECATION")
        val extRoot = android.os.Environment.getExternalStorageDirectory().apply { mkdirs() }
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        ).apply { mkdirs() }

        val customRootFolder = File(extRoot, "BarqCustomWorkspace").apply {
            deleteRecursively()
            mkdirs()
        }
        val rootLevelFile = File(extRoot, "root_readme_barq.txt").apply {
            writeBytes("Root level file in shared storage".toByteArray())
        }
        val androidRootDir = File(extRoot, "Android").apply { mkdirs() }
        File(androidRootDir, "media").mkdirs()

        val gameModFolder = File(downloadRoot, "barq_game_pack").apply {
            deleteRecursively()
            mkdirs()
        }
        val emptyDownloadSubFolder = File(downloadRoot, "empty_user_folder").apply {
            deleteRecursively()
            mkdirs()
        }
        val massiveBatchFiles = mutableListOf<File>()
        val obbSubFolder = File(gameModFolder, "obb_data").apply { mkdirs() }
        val receiveBaseDir = File(context.cacheDir, "handshake_receive_${System.currentTimeMillis()}").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            val apkBytes = Random(901).nextBytes(72 * 1024 + 11)
            val obbBytes = Random(902).nextBytes(120 * 1024 + 33)
            val apkFile = File(gameModFolder, "barq_arena.apk").apply { writeBytes(apkBytes) }
            val obbFile = File(obbSubFolder, "main.101.com.barq.arena.obb").apply { writeBytes(obbBytes) }

            // Create 450 real files directly inside Download to test large folder opening without ANR
            for (idx in 1..450) {
                val f = File(downloadRoot, "bulk_download_item_$idx.dat")
                f.writeBytes(byteArrayOf(idx.toByte(), 1, 2, 3))
                massiveBatchFiles.add(f)
            }

            val (loadedFiles, loadedFolders) = DeviceMediaRepository.loadGeneralFilesAndFolders(context)

            // 0. Verify Root of Shared Internal Storage ("") dynamically lists real folders (> 6 folders, including Android & customRootFolder) and root-level files
            val (rootFolders, rootFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue(
                "Root of internal storage must dynamically list more than 6 static folders (found ${rootFolders.size})",
                rootFolders.size > 6
            )
            assertTrue(
                "Root of internal storage must include 'Android' folder",
                rootFolders.any { it.name.equals("Android", ignoreCase = true) }
            )
            assertTrue(
                "Root of internal storage must include custom folder 'BarqCustomWorkspace'",
                rootFolders.any { it.name == "BarqCustomWorkspace" }
            )
            assertTrue(
                "Root of internal storage must list root-level file 'root_readme_barq.txt'",
                rootFiles.any { it.name == "root_readme_barq.txt" }
            )

            // 1. Verify hierarchical browsing inside "Download" with 450+ files & empty subfolder completes fast (< 500ms) with progressive batch callback
            var partialBatchFired = false
            val browseStartNano = System.nanoTime()
            val (downloadSubfolders, downloadImmediateFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles,
                onPartialResult = { _, partialFiles ->
                    if (partialFiles.isNotEmpty()) {
                        partialBatchFired = true
                    }
                }
            )
            val browseElapsedMs = (System.nanoTime() - browseStartNano) / 1_000_000L
            assertTrue(
                "Opening 'Download' with 450+ files must complete in < 500ms without ANR (took ${browseElapsedMs}ms)",
                browseElapsedMs < 500L
            )
            assertTrue("Progressive partial batch must fire for large Download folder", partialBatchFired)
            assertTrue(
                "Browsing 'Download' must list 'barq_game_pack' and 'empty_user_folder' as child folders",
                downloadSubfolders.any { it.name == "barq_game_pack" } &&
                    downloadSubfolders.any { it.name == "empty_user_folder" }
            )
            assertTrue(
                "Browsing 'Download' must list all 450+ immediate files",
                downloadImmediateFiles.size >= 450
            )

            // Verify browsing an empty folder returns empty lists cleanly without error
            val (emptyDirs, emptyFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/empty_user_folder",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue("Empty folder must return 0 subfolders and 0 files", emptyDirs.isEmpty() && emptyFiles.isEmpty())

            val (packSubfolders, packFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/barq_game_pack",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue(
                "Browsing 'Download/barq_game_pack' must list 'obb_data' subfolder",
                packSubfolders.any { it.name == "obb_data" }
            )
            assertTrue(
                "Browsing 'Download/barq_game_pack' must list 'barq_arena.apk' with APK extension badge",
                packFiles.any { it.name == "barq_arena.apk" && it.fileExtensionBadge == "APK" }
            )

            // 2. Verify ViewModel parent directory navigation (navigateUpDirectory) & async cache restoration
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            vm.setBrowsingFolderFilter("Download")
            val dlWaitDeadline = System.currentTimeMillis() + 3_000L
            while (System.currentTimeMillis() < dlWaitDeadline &&
                (vm.uiState.value.isBrowsingDirectoryLoading || vm.uiState.value.currentBrowsingFiles.size < 450)
            ) {
                Thread.sleep(20)
            }
            assertTrue(
                "ViewModel async browse for Download must populate currentBrowsingFiles",
                vm.uiState.value.currentBrowsingFiles.size >= 450
            )
            vm.setBrowsingFolderFilter("Download/barq_game_pack/obb_data")
            assertEquals("Download/barq_game_pack/obb_data", vm.uiState.value.browsingFolderFilter)
            vm.navigateUpDirectory()
            assertEquals("Download/barq_game_pack", vm.uiState.value.browsingFolderFilter)
            vm.navigateUpDirectory()
            assertEquals("Download", vm.uiState.value.browsingFolderFilter)
            assertTrue(
                "Navigating back to 'Download' must immediately restore cached files without reloading from zero",
                vm.uiState.value.currentBrowsingFiles.size >= 450
            )
            vm.navigateUpDirectory()
            assertEquals(null, vm.uiState.value.browsingFolderFilter)

            // 3. Verify Two-Device Session Handshake & Explicit Sender Approval Security
            val scanResult = DeviceMediaRepository.scanLocalFolderForTransfer(
                rootDir = gameModFolder,
                chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes
            )
            val preparedItems = scanResult.transferItems.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-8899"
            val sessionId = "SES-A1B2C3"
            val expiresAt = System.currentTimeMillis() + 600_000L
            var observedIncomingReq: com.example.model.IncomingConnectionRequest? = null

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                sessionIdProvider = { sessionId },
                sessionExpiresAtProvider = { expiresAt },
                isSenderReadyProvider = { true },
                requireReceiverApprovalProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { preparedItems },
                onIncomingConnectionRequest = { req -> observedIncomingReq = req },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // Step A: Receiver fetches manifest -> succeeds (200) and reports requiresApproval = true
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestJson = JSONObject(manifestConn.inputStream.bufferedReader().use { it.readText() })
                manifestConn.disconnect()
                assertEquals(sessionId, manifestJson.getString("sessionId"))
                assertTrue(manifestJson.getBoolean("requiresApproval"))

                // Step B: Unauthorized Receiver tries to download /api/stream BEFORE Sender approval -> MUST BE REJECTED (HTTP 403)
                val firstFileId = preparedItems.first { !it.isDirectory }.id
                val unauthStreamConn = (URL("http://127.0.0.1:$port/api/stream?code=$sessionCode&fileId=$firstFileId&offset=0").openConnection() as HttpURLConnection)
                assertEquals(
                    "Stream download MUST be blocked with HTTP 403 before Sender approves connection",
                    403,
                    unauthStreamConn.responseCode
                )
                unauthStreamConn.disconnect()

                // Step C: Receiver sends /api/request-connect
                val reqConn = (URL("http://127.0.0.1:$port/api/request-connect?code=$sessionCode&deviceName=Pixel_Receiver&clientId=RCV-101").openConnection() as HttpURLConnection)
                assertEquals(200, reqConn.responseCode)
                val reqJson = JSONObject(reqConn.inputStream.bufferedReader().use { it.readText() })
                reqConn.disconnect()
                assertEquals("PENDING", reqJson.getString("status"))
                assertNotNull("Sender must receive IncomingConnectionRequest callback", observedIncomingReq)
                assertEquals("Pixel_Receiver", observedIncomingReq?.clientDeviceName)

                // Step D: Receiver polls /api/connect-status while still pending -> PENDING
                val pollPendingConn = (URL("http://127.0.0.1:$port/api/connect-status?code=$sessionCode&requestId=${observedIncomingReq!!.requestId}").openConnection() as HttpURLConnection)
                val pollPendingJson = JSONObject(pollPendingConn.inputStream.bufferedReader().use { it.readText() })
                pollPendingConn.disconnect()
                assertEquals("PENDING", pollPendingJson.getString("status"))

                // Step E: Sender approves the incoming connection request -> issues cryptographic authToken
                val issuedToken = server.approvePendingConnectionRequest()
                assertTrue("Issued auth token must not be blank", issuedToken.isNotBlank())

                // Step F: Receiver polls /api/connect-status -> APPROVED + authToken
                val pollApprovedConn = (URL("http://127.0.0.1:$port/api/connect-status?code=$sessionCode&requestId=${observedIncomingReq!!.requestId}").openConnection() as HttpURLConnection)
                val pollApprovedJson = JSONObject(pollApprovedConn.inputStream.bufferedReader().use { it.readText() })
                pollApprovedConn.disconnect()
                assertEquals("APPROVED", pollApprovedJson.getString("status"))
                assertEquals(issuedToken, pollApprovedJson.getString("authToken"))

                // Step G: Receiver executes high-speed transfer using the approved authToken and verifies SHA-256
                var receiverItems = preparedItems
                val completed = mutableListOf<TransferFileItem>()
                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    authToken = issuedToken,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completed) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completed) { completed.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                assertFalse("Approved transfer must complete without errors", anyFailed)
                assertEquals(preparedItems.size, completed.size)
                assertTrue(File(receiveBaseDir, "barq_game_pack/barq_arena.apk").readBytes().contentEquals(apkBytes))
                assertTrue(File(receiveBaseDir, "barq_game_pack/obb_data/main.101.com.barq.arena.obb").readBytes().contentEquals(obbBytes))
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            customRootFolder.deleteRecursively()
            rootLevelFile.delete()
            emptyDownloadSubFolder.deleteRecursively()
            massiveBatchFiles.forEach { it.delete() }
            gameModFolder.deleteRecursively()
            receiveBaseDir.deleteRecursively()
        }
    }

    @Test
    fun verifyCrashFreeMediaAndUriTransferAndCompactFilesViewport() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "crash_guard_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempRoot, "received_out").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // 1. Test transferring a multi-megabyte video via Uri (content/file URI fallback),
            //    an image with special '%' and Arabic characters in its filename, and a broken URI.
            val videoBytes = Random(2025).nextBytes(4 * 1024 * 1024 + 517) // ~4 MB video
            val videoFile = File(tempRoot, "4K_Capture_100%_سباق.mp4").apply { writeBytes(videoBytes) }
            val videoSha = Sha256Util.computeFileSha256(videoFile)

            val imageBytes = Random(2026).nextBytes(320 * 1024 + 19)
            val imageFile = File(tempRoot, "صورة_خاصة_50%+1.jpg").apply { writeBytes(imageBytes) }
            val imageSha = Sha256Util.computeFileSha256(imageFile)

            // Pass video Item with ONLY uri (localFile = null) so P2PChunkServer exercises its URI streaming path
            val videoUri = android.net.Uri.fromFile(videoFile)
            val validItems = listOf(
                TransferFileItem(
                    id = "uri_video_100%A",
                    name = videoFile.name,
                    sizeBytes = videoFile.length(),
                    category = FileCategory.VIDEO,
                    uri = videoUri,
                    localFile = null,
                    totalChunks = 8,
                    completedChunks = 0,
                    sha256Expected = videoSha
                ),
                TransferFileItem(
                    id = "special_img_50%",
                    name = imageFile.name,
                    sizeBytes = imageFile.length(),
                    category = FileCategory.IMAGE,
                    localFile = imageFile,
                    totalChunks = 2,
                    completedChunks = 0,
                    sha256Expected = imageSha
                )
            )

            val sessionCode = "BRQ-9911"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_512KB },
                filesProvider = { validItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var receiverItems = validItems
                val completed = mutableListOf<TransferFileItem>()
                val errors = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completed) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completed) { completed.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(errors) { errors.add(err) }
                    }
                )

                assertFalse("URI video and special-char image transfer must succeed without crashes: $errors", anyFailed)
                assertEquals(2, completed.size)
                assertTrue(File(receiveDir, videoFile.name).readBytes().contentEquals(videoBytes))
                assertTrue(File(receiveDir, imageFile.name).readBytes().contentEquals(imageBytes))

                // 2. Verify that a revoked/missing content:// URI does NOT crash the server or receiver,
                //    and instead reports a graceful Arabic error via onFileFailed
                val brokenItem = TransferFileItem(
                    id = "revoked_uri_item",
                    name = "revoked_video.mp4",
                    sizeBytes = 1024 * 1024L,
                    category = FileCategory.VIDEO,
                    uri = android.net.Uri.parse("content://com.nonexistent.provider.barq/video/999999"),
                    localFile = null,
                    totalChunks = 2,
                    completedChunks = 0,
                    sha256Expected = ""
                )
                val brokenServer = P2PChunkServer(
                    context = context,
                    scope = serverScope,
                    sessionCodeProvider = { sessionCode },
                    isSenderReadyProvider = { true },
                    chunkSizeProvider = { ChunkSizeOption.CHUNK_512KB },
                    filesProvider = { listOf(brokenItem) },
                    onChunkServed = { _, _, _ -> }
                )
                val brokenPort = brokenServer.startServer(0)
                try {
                    Thread.sleep(80)
                    var brokenState = listOf(brokenItem)
                    val brokenErrors = mutableListOf<String>()
                    val brokenFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                        hostIp = "127.0.0.1",
                        hostPort = brokenPort,
                        sessionCode = sessionCode,
                        chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                        downloadDir = receiveDir,
                        itemsProvider = { brokenState },
                        isPausedProvider = { false },
                        onFileUpdated = { fileId, _, _, transform ->
                            brokenState = brokenState.map { if (it.id == fileId) transform(it) else it }
                        },
                        onFileCompleted = { _, _ -> },
                        onFileFailed = { _, err -> brokenErrors.add(err) }
                    )
                    assertTrue("Revoked URI must fail gracefully instead of crashing", brokenFailed)
                    assertTrue("Graceful failure message must be recorded", brokenErrors.isNotEmpty())
                } finally {
                    brokenServer.stopServer()
                }
            } finally {
                server.stopServer()
            }

            // 3. Verify Real Android File Manager layout, default root folders, breadcrumb bar, and direct folder opening
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_FILES"))
            composeTestRule.onNodeWithTag("bottom_nav_FILES").performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("files_and_folders_search_input").assertIsDisplayed()
            composeTestRule.onNodeWithTag("file_manager_breadcrumb_bar").assertIsDisplayed()
            composeTestRule.onNodeWithTag("sort_dropdown_button").assertExists()
            composeTestRule.onNodeWithTag("pick_saf_folder_in_manager_button").assertExists()
            composeTestRule.onNodeWithTag("files_manager_lazy_column").assertIsDisplayed()

            // Verify internal storage root folders (Download, DCIM) are automatically displayed without "0 مجلد"
            composeTestRule.onNodeWithTag("folder_item_card_Download").assertExists()
            composeTestRule.onNodeWithTag("folder_item_card_DCIM").assertExists()

            // Click directly on Download folder to open it, then verify "المجلد السابق ↑" button appears and navigates back
            composeTestRule.onNodeWithTag("folder_item_card_Download").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("navigate_up_folder_button").assertIsDisplayed()
            composeTestRule.onNodeWithTag("navigate_up_folder_button").performClick()
            composeTestRule.waitForIdle()

            // Toggle manual folder path bar and verify it opens and closes cleanly
            composeTestRule.onNodeWithTag("toggle_custom_folder_bar_button").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("custom_folder_path_input").assertIsDisplayed()
            composeTestRule.onNodeWithTag("toggle_custom_folder_bar_button").performClick()
            composeTestRule.waitForIdle()
        } finally {
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyAutoMaxDefaultQrRoundTripAndReceivedApksManager(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)

        // 1. Verify "أقصى سرعة تلقائية (Auto Max)" is the default chunk mode in every session without manual intervention
        assertEquals(
            "Default chunk size must be AUTO_MAX without manual user selection",
            ChunkSizeOption.AUTO_MAX,
            vm.uiState.value.selectedChunkSize
        )
        assertEquals(
            "Default remote chunk size must match AUTO_MAX bytes (8 MB)",
            ChunkSizeOption.AUTO_MAX.bytes,
            vm.uiState.value.remoteChunkSizeBytes
        )

        // 2. Verify SortOption.TYPE_ASC exists and works in ViewModel
        vm.setSortOption(com.example.model.SortOption.TYPE_ASC)
        assertEquals(com.example.model.SortOption.TYPE_ASC, vm.uiState.value.sortOption)

        // 3. Verify real QR Code encoding + matrix decoding + luminance camera frame decoding round-trip
        val qrPayload = "BARQP2P|192.168.43.1|8989|BRQ-7744|SES-998877"
        val matrix = com.example.util.QrCodeGenerator.encodeToMatrix(qrPayload)
        val decodedDirect = com.example.util.QrCodeGenerator.decodeMatrix(matrix)
        assertEquals("Direct QR matrix decoder must recover exact session payload", qrPayload, decodedDirect)

        // Synthesize a camera Y-plane (luminance frame) with quiet zone around the QR matrix and decode it
        val n = matrix.size
        val scale = 6
        val quiet = 4
        val frameSize = (n + quiet * 2) * scale
        val yPlane = ByteArray(frameSize * frameSize) { 240.toByte() } // White background
        for (r in 0 until n) {
            for (c in 0 until n) {
                val lum = if (matrix[r][c]) 16.toByte() else 240.toByte()
                val startY = (r + quiet) * scale
                val startX = (c + quiet) * scale
                for (dy in 0 until scale) {
                    for (dx in 0 until scale) {
                        yPlane[(startY + dy) * frameSize + (startX + dx)] = lum
                    }
                }
            }
        }
        val decodedFromCameraFrame = com.example.util.QrCodeGenerator.tryDecodeLumaFrame(
            yPlane = yPlane,
            width = frameSize,
            height = frameSize,
            rowStride = frameSize
        )
        assertEquals(
            "Camera luminance frame decoder must recover exact session payload",
            qrPayload,
            decodedFromCameraFrame
        )

        // 4. Verify Received APKs inspection (corrupted vs valid ZIP header handling) and UI screen navigation
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        )
        val barqReceiveDir = File(downloadRoot, "Barq_P2P").apply { mkdirs() }
        val corruptApk = File(barqReceiveDir, "incomplete_corrupt_test.apk")
        val emptyApk = File(barqReceiveDir, "empty_zero_test.apk")
        try {
            corruptApk.writeBytes("NOT_A_VALID_ZIP_OR_APK_HEADER".toByteArray())
            emptyApk.writeBytes(ByteArray(0))

            val corruptInspect = DeviceMediaRepository.inspectApkFile(context, corruptApk)
            assertFalse("Corrupted non-ZIP file must be marked isValidApk = false", corruptInspect.isValidApk)
            assertTrue("Corrupted APK status message must explain reason", corruptInspect.statusMessage.isNotBlank())

            val emptyInspect = DeviceMediaRepository.inspectApkFile(context, emptyApk)
            assertFalse("0-byte APK must be marked isValidApk = false", emptyInspect.isValidApk)

            val loadedApks = DeviceMediaRepository.loadReceivedApkFiles(context)
            assertTrue(
                "loadReceivedApkFiles must discover APK files inside Download/Barq_P2P",
                loadedApks.any { it.fileName == "incomplete_corrupt_test.apk" }
            )

            // Navigate to RECEIVED_APKS tab in MainActivity and verify UI renders
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_RECEIVED_APKS"))
            composeTestRule.onNodeWithTag("bottom_nav_RECEIVED_APKS").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("refresh_received_apks_button").assertIsDisplayed()
        } finally {
            corruptApk.delete()
            emptyApk.delete()
        }
    }

    @Test
    fun verifyMassiveMediaLibrary40GbVideosAndBluetoothProtocolAndUi(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "bt_and_40gb_test_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            // 1. Verify bounded LruCache thumbnail behavior and fast handling of 3,200+ items & 40 GB videos
            DeviceMediaRepository.clearThumbnailCache()
            val sampleImgFile = File(tempDir, "thumb_sample.jpg")
            val bmp = android.graphics.Bitmap.createBitmap(160, 160, android.graphics.Bitmap.Config.RGB_565)
            java.io.FileOutputStream(sampleImgFile).use { out ->
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
            }
            val mediaItem = com.example.model.DeviceMediaItem(
                id = "img_test_lru_1",
                name = "thumb_sample.jpg",
                sizeBytes = sampleImgFile.length(),
                category = FileCategory.IMAGE,
                dateModifiedMillis = 1_700_000_000_000L,
                localFile = sampleImgFile
            )
            val loadedThumb = DeviceMediaRepository.getOrLoadThumbnailAsync(context, mediaItem)
            assertNotNull("On-demand async thumbnail loader must decode and cache visible image thumbnail", loadedThumb)
            assertNotNull("Thumbnail must be retrievable synchronously from bounded LruCache", DeviceMediaRepository.getCachedThumbnail("img_test_lru_1"))

            // Simulate 3,200 media items including 40 GB (42,949,672,960 bytes) videos
            val fortyGbBytes = 40L * 1024L * 1024L * 1024L
            val massiveListStart = System.nanoTime()
            val massiveItems = (1..3200).map { idx ->
                com.example.model.DeviceMediaItem(
                    id = "mass_$idx",
                    name = if (idx % 50 == 0) "UltraHD_Movie_$idx.mp4" else "IMG_${10000 + idx}.jpg",
                    sizeBytes = if (idx % 50 == 0) fortyGbBytes else 4_500_000L,
                    category = if (idx % 50 == 0) FileCategory.VIDEO else FileCategory.IMAGE,
                    dateModifiedMillis = 1_700_000_000_000L + idx * 1000L,
                    durationMillis = if (idx % 50 == 0) 7_200_000L else 0L,
                    bucketOrFolderName = if (idx % 2 == 0) "Camera" else "DCIM"
                )
            }
            val searchMatched = massiveItems.filter { it.name.contains("UltraHD_Movie_1500", ignoreCase = true) }
            val elapsedMs = (System.nanoTime() - massiveListStart) / 1_000_000L
            assertEquals(1, searchMatched.size)
            assertEquals(fortyGbBytes, searchMatched.first().sizeBytes)
            assertTrue("Filtering 3,200 metadata items with 40 GB videos must complete in < 250ms (took ${elapsedMs}ms)", elapsedMs < 250L)

            // 2. Verify Bluetooth Classic RFCOMM Stream Handshake + Direct File Transfer over socket streams
            val btPayloadBytes = Random(777).nextBytes(256 * 1024 + 333) // ~256 KB file for Bluetooth stream test
            val btSourceFile = File(tempDir, "bluetooth_test_doc.pdf").apply { writeBytes(btPayloadBytes) }
            val btExpectedSha = Sha256Util.computeFileSha256(btSourceFile)
            val btTransferItem = TransferFileItem(
                id = "bt_file_1",
                name = btSourceFile.name,
                sizeBytes = btSourceFile.length(),
                category = FileCategory.DOCUMENT,
                localFile = btSourceFile,
                totalChunks = 1,
                sha256Expected = btExpectedSha
            )

            java.net.ServerSocket(0).use { loopServer ->
                val loopPort = loopServer.localPort
                val serverThread = Thread {
                    repeat(2) {
                        val accepted = loopServer.accept()
                        accepted.use { s ->
                            com.example.network.BluetoothP2PManager.handleServerConnectionStreams(
                                context = context,
                                input = s.getInputStream(),
                                output = s.getOutputStream(),
                                localIp = "192.168.43.1",
                                localPort = 8989,
                                sessionCode = "BRQ-4040",
                                sessionId = "SES-BT40",
                                senderDeviceName = "Galaxy_S24_Sender",
                                filesProvider = { listOf(btTransferItem) },
                                onBytesServed = { _: String, _: Long -> }
                            )
                        }
                    }
                }.apply { isDaemon = true; start() }

                // Connection 1: Client Handshake over Bluetooth stream
                java.net.Socket("127.0.0.1", loopPort).use { clientSock1 ->
                    val handshakeJson = com.example.network.BluetoothP2PManager.performClientHandshakeOverStreams(
                        input = clientSock1.getInputStream(),
                        output = clientSock1.getOutputStream(),
                        clientDeviceName = "Pixel_9_Receiver"
                    )
                    assertEquals("BRQ-4040", handshakeJson.getString("sessionCode"))
                    assertEquals("SES-BT40", handshakeJson.getString("sessionId"))
                    assertEquals("192.168.43.1", handshakeJson.getString("hostIp"))
                    assertEquals(1, handshakeJson.getJSONArray("files").length())
                }

                // Connection 2: Direct Bluetooth File Stream & SHA-256 verification
                val btDestFile = File(tempDir, "received_via_bt.pdf")
                java.net.Socket("127.0.0.1", loopPort).use { clientSock2 ->
                    val (btOk, btShaOrErr) = com.example.network.BluetoothP2PManager.downloadSingleFileOverBluetoothStreams(
                        item = btTransferItem,
                        input = clientSock2.getInputStream(),
                        output = clientSock2.getOutputStream(),
                        destFile = btDestFile,
                        onProgress = { _: Long, _: Double -> }
                    )
                    assertTrue("Direct Bluetooth stream transfer must succeed: $btShaOrErr", btOk)
                    assertEquals(btExpectedSha, btShaOrErr)
                    assertTrue("Received Bluetooth file bytes must match original", btDestFile.readBytes().contentEquals(btPayloadBytes))
                }
                serverThread.join(2000)
            }

            // 3. Verify Transport Mode & Bluetooth UI card on SEND screen
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_SEND"))
            composeTestRule.onNodeWithTag("bottom_nav_SEND").performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("bluetooth_and_transport_mode_card").assertExists()
            composeTestRule.onNodeWithTag("transport_mode_chip_AUTO_SMART").assertExists()
            composeTestRule.onNodeWithTag("transport_mode_chip_BLUETOOTH_DIRECT").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("transport_mode_chip_AUTO_SMART").performClick()
            composeTestRule.waitForIdle()
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun verifyLarge3GbMathMultiVideoQueuePartResumeForegroundServiceAndHistoryMediaPlayback(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "barq_3gb_resume_history_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempRoot, "received_videos").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            P2PTransferViewModel.resetRetainedEngineForTests()

            // 1. Verify 2.9 GB - 3 GB (3,150,000,000 bytes > Int.MAX_VALUE) Long math & progress precision
            val threeGbBytes = 3_150_000_000L
            val halfThreeGbBytes = 1_575_000_000L
            val chunkBytesLong = ChunkSizeOption.AUTO_MAX.bytes.toLong()
            val expected3GbChunks = ((threeGbBytes + chunkBytesLong - 1L) / chunkBytesLong).toInt()
            assertTrue("3 GB totalChunks must be positive and never overflow Int", expected3GbChunks > 350)
            val chunk4MbLong = ChunkSizeOption.CHUNK_4MB.bytes.toLong()
            val expected3Gb4MbChunks = ((threeGbBytes + chunk4MbLong - 1L) / chunk4MbLong).toInt()
            assertTrue("3 GB 4MB totalChunks must be > 700 and never overflow Int", expected3Gb4MbChunks > 700)

            val large3GbItem = TransferFileItem(
                id = "movie_3gb",
                name = "Cinema_4K_Master_2_9GB.mp4",
                sizeBytes = threeGbBytes,
                transferredBytes = halfThreeGbBytes,
                category = FileCategory.VIDEO,
                totalChunks = expected3GbChunks,
                completedChunks = expected3GbChunks / 2,
                status = FileTransferStatus.TRANSFERRING
            )
            assertEquals("3 GB 50% progressPercent must be 50%", 50, large3GbItem.progressPercent)
            assertEquals(0.5f, large3GbItem.progressFraction, 0.001f)

            val uiState3Gb = com.example.viewmodel.P2PUiState(
                files = listOf(large3GbItem),
                isTransferRunning = true,
                liveOverallSpeedBytesPerSec = 52_500_000.0
            )
            assertEquals(threeGbBytes, uiState3Gb.totalBytes)
            assertEquals(halfThreeGbBytes, uiState3Gb.transferredBytes)
            assertEquals(0.5f, uiState3Gb.overallProgressFraction, 0.001f)
            assertEquals(0, uiState3Gb.completedFilesOnlyCount)
            assertEquals(1, uiState3Gb.remainingFilesOnlyCount)
            assertEquals("Cinema_4K_Master_2_9GB.mp4", uiState3Gb.activeTransferringFile?.name)

            // 2. Verify Sequential Multi-Video Transfer + Mid-Transfer Disconnect (.part) & Exact Byte-Offset Resume
            val video1Bytes = Random(301).nextBytes(4 * 1024 * 1024 + 50_123) // > 4 MB -> enters largeFiles sequential queue
            val video2Bytes = Random(302).nextBytes(4 * 1024 * 1024 + 120_456)
            val video3Bytes = Random(303).nextBytes(4 * 1024 * 1024 + 210_789)

            val video1File = File(tempRoot, "video_250mb_clip.mp4").apply { writeBytes(video1Bytes) }
            val video2File = File(tempRoot, "video_300mb_clip.mp4").apply { writeBytes(video2Bytes) }
            val video3File = File(tempRoot, "video_400mb_clip.mp4").apply { writeBytes(video3Bytes) }

            val videoItems = listOf(video1File, video2File, video3File).mapIndexed { idx, f ->
                val cSize = ChunkSizeOption.CHUNK_256KB.bytes.toLong()
                TransferFileItem(
                    id = "seq_vid_$idx",
                    name = f.name,
                    sizeBytes = f.length(),
                    category = FileCategory.VIDEO,
                    localFile = f,
                    totalChunks = ((f.length() + cSize - 1L) / cSize).toInt(),
                    sha256Expected = Sha256Util.computeFileSha256(f)
                )
            }

            // Simulate a previous interrupted transfer where 1.5 MB of video_250mb_clip.mp4 was written to .part
            val partialPrefixLen = 1_500_000
            val partFile1 = File(receiveDir, "${video1File.name}.part").apply {
                writeBytes(video1Bytes.copyOfRange(0, partialPrefixLen))
            }
            assertTrue("Partial .part file must exist before resume", partFile1.exists() && partFile1.length() == partialPrefixLen.toLong())

            val requestedOffsetsForVid0 = mutableListOf<Long>()
            val sessionCode = "BRQ-3000"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { videoItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var currentVideoState = videoItems.mapIndexed { idx, item ->
                    if (idx == 0) item.copy(transferredBytes = partialPrefixLen.toLong(), completedChunks = 6) else item
                }
                val completedOrder = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { currentVideoState },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedOrder) {
                            currentVideoState = currentVideoState.map {
                                if (it.id == fileId) {
                                    val updated = transform(it)
                                    if (fileId == "seq_vid_0" && updated.transferredBytes >= partialPrefixLen.toLong()) {
                                        requestedOffsetsForVid0.add(updated.transferredBytes)
                                    }
                                    updated
                                } else it
                            }
                        }
                    },
                    onFileCompleted = { doneItem, _ ->
                        synchronized(completedOrder) {
                            completedOrder.add(doneItem.name)
                        }
                    },
                    onFileFailed = { _, err ->
                        throw AssertionError("Multi-video sequential transfer should not fail: $err")
                    }
                )

                assertFalse("Sequential multi-video transfer with .part resume must succeed", anyFailed)
                assertEquals(
                    "Videos > 4 MB must complete in strict sequential order",
                    listOf("video_250mb_clip.mp4", "video_300mb_clip.mp4", "video_400mb_clip.mp4"),
                    completedOrder
                )
                assertTrue(
                    "Resumed video must start at or above the 1.5 MB .part offset without resetting to 0",
                    requestedOffsetsForVid0.isNotEmpty() && requestedOffsetsForVid0.first() >= partialPrefixLen.toLong()
                )
                assertFalse(".part temporary file must be renamed after completion", partFile1.exists())

                for ((idx, srcFile) in listOf(video1File, video2File, video3File).withIndex()) {
                    val savedVideo = File(receiveDir, srcFile.name)
                    assertTrue("Saved video $idx must exist", savedVideo.exists())
                    assertEquals("Saved video $idx length must match", srcFile.length(), savedVideo.length())
                    assertEquals(
                        "Saved video $idx SHA-256 must match 100%",
                        videoItems[idx].sha256Expected,
                        Sha256Util.computeFileSha256(savedVideo)
                    )
                }
            } finally {
                server.stopServer()
            }

            // 3. Verify BarqTransferForegroundService Notification + WakeLock/WifiLock lifecycle
            com.example.service.BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = com.example.model.TransferDirection.RECEIVING,
                currentFileName = "Cinema_4K_Master_2_9GB.mp4",
                completedFiles = 1,
                totalFiles = 3,
                transferredBytes = halfThreeGbBytes,
                totalBytes = threeGbBytes,
                speedBytesPerSec = 48L * 1024L * 1024L,
                forceUpdate = true
            )
            assertTrue(
                "Foreground transfer service must be marked active during transfer",
                com.example.service.BarqTransferForegroundService.isServiceActive
            )
            assertEquals(500, com.example.service.BarqTransferForegroundService.lastProgressPermille)
            assertTrue(
                "Notification body must display current file name",
                com.example.service.BarqTransferForegroundService.lastNotificationBody.contains("Cinema_4K_Master_2_9GB.mp4")
            )

            com.example.service.BarqTransferForegroundService.stopTransferService(context)
            assertFalse(
                "Foreground transfer service must stop immediately when transfer finishes",
                com.example.service.BarqTransferForegroundService.isServiceActive
            )
            assertFalse(
                "WakeLock must be released when transfer service stops",
                com.example.service.BarqTransferForegroundService.isWakeLockHeld
            )
            assertFalse(
                "WifiLock must be released when transfer service stops",
                com.example.service.BarqTransferForegroundService.isWifiLockHeld
            )

            // 4. Verify Downloads History persistence & direct Video Playback (▶ تشغيل الفيديو) + Image Viewing (عرض الصورة)
            val savedImgFile = File(receiveDir, "downloaded_poster.jpg")
            val bmp = android.graphics.Bitmap.createBitmap(240, 180, android.graphics.Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.CYAN)
            java.io.FileOutputStream(savedImgFile).use { out ->
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
            }
            val savedVidFile = File(receiveDir, "video_250mb_clip.mp4")
            val incompletePartPath = File(receiveDir, "unfinished_movie.mp4.part").apply {
                writeBytes(ByteArray(1024))
            }

            val completedVideoRecord = com.example.model.TransferHistoryRecord(
                id = "hist_vid_1",
                fileName = savedVidFile.name,
                sizeBytes = savedVidFile.length(),
                category = FileCategory.VIDEO,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.COMPLETED,
                timestampMillis = System.currentTimeMillis(),
                savedPath = savedVidFile.absolutePath,
                uriString = android.net.Uri.fromFile(savedVidFile).toString(),
                mimeType = "video/mp4",
                sha256Hash = Sha256Util.computeFileSha256(savedVidFile),
                sha256Verified = true,
                averageSpeedBytesPerSec = 42_000_000.0,
                peerAddress = "192.168.43.1"
            )
            val completedImageRecord = com.example.model.TransferHistoryRecord(
                id = "hist_img_1",
                fileName = savedImgFile.name,
                sizeBytes = savedImgFile.length(),
                category = FileCategory.IMAGE,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.COMPLETED,
                timestampMillis = System.currentTimeMillis() - 5000L,
                savedPath = savedImgFile.absolutePath,
                uriString = android.net.Uri.fromFile(savedImgFile).toString(),
                mimeType = "image/jpeg",
                sha256Hash = Sha256Util.computeFileSha256(savedImgFile),
                sha256Verified = true,
                averageSpeedBytesPerSec = 35_000_000.0,
                peerAddress = "192.168.43.1"
            )
            val failedPartialRecord = com.example.model.TransferHistoryRecord(
                id = "hist_fail_1",
                fileName = "unfinished_movie.mp4",
                sizeBytes = 300_000_000L,
                category = FileCategory.VIDEO,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.FAILED,
                timestampMillis = System.currentTimeMillis() - 10_000L,
                savedPath = incompletePartPath.absolutePath,
                errorMessage = "انقطع الاتصال أثناء التحميل"
            )

            assertTrue(completedVideoRecord.isCompleted && completedVideoRecord.isVideoFile)
            assertTrue(completedImageRecord.isCompleted && completedImageRecord.isImageFile)
            assertFalse("Incomplete .part record must NEVER be marked isCompleted", failedPartialRecord.isCompleted)

            // Write history JSON to filesDir and verify ViewModel loads it on startup and opens exact media in UI
            val historyJsonArr = org.json.JSONArray()
            for (r in listOf(completedVideoRecord, completedImageRecord, failedPartialRecord)) {
                val o = JSONObject().apply {
                    put("id", r.id)
                    put("fileName", r.fileName)
                    put("sizeBytes", r.sizeBytes)
                    put("category", r.category.name)
                    put("direction", r.direction.name)
                    put("status", r.status.name)
                    put("timestampMillis", r.timestampMillis)
                    put("savedPath", r.savedPath ?: "")
                    put("uriString", r.uriString ?: "")
                    put("mimeType", r.mimeType ?: "")
                    put("sha256Hash", r.sha256Hash)
                    put("sha256Verified", r.sha256Verified)
                    put("averageSpeedBytesPerSec", r.averageSpeedBytesPerSec)
                    put("peerAddress", r.peerAddress)
                    put("errorMessage", r.errorMessage ?: "")
                }
                historyJsonArr.put(o)
            }
            File(context.filesDir, "barq_transfer_history.json").writeText(historyJsonArr.toString())

            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            val loadDeadline = System.currentTimeMillis() + 3_000L
            while (System.currentTimeMillis() < loadDeadline && vm.uiState.value.transferHistory.size < 3) {
                Thread.sleep(40)
            }
            assertEquals("ViewModel must load persisted transfer history across restarts", 3, vm.uiState.value.transferHistory.size)

            // Test opening completed Image in-app -> sets previewingHistoryRecord to exact image
            vm.openHistoryMediaInApp(completedImageRecord)
            assertEquals("hist_img_1", vm.uiState.value.previewingHistoryRecord?.id)
            assertEquals(savedImgFile.absolutePath, vm.uiState.value.previewingHistoryRecord?.savedPath)
            vm.closeHistoryMediaPreview()
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)

            // Test opening completed Video in-app -> sets previewingHistoryRecord to exact video
            vm.openHistoryMediaInApp(completedVideoRecord)
            assertEquals("hist_vid_1", vm.uiState.value.previewingHistoryRecord?.id)
            assertEquals(savedVidFile.absolutePath, vm.uiState.value.previewingHistoryRecord?.savedPath)
            vm.closeHistoryMediaPreview()

            // Test attempting to open incomplete/failed record -> refused with clear Arabic message
            vm.openHistoryMediaInApp(failedPartialRecord)
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)
            assertTrue(
                "Incomplete file open attempt must show clear Arabic warning",
                vm.uiState.value.statusBannerMessage.orEmpty().contains("لم تكتمل")
            )

            // Test deleting a file and attempting to open it -> graceful Arabic message without crash
            val deletedFileRecord = completedImageRecord.copy(
                id = "hist_deleted_1",
                fileName = "deleted_photo.jpg",
                savedPath = File(receiveDir, "non_existent_deleted_photo.jpg").absolutePath
            )
            vm.openHistoryMediaInApp(deletedFileRecord)
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)
            assertTrue(
                "Deleted file open attempt must explain file is missing",
                vm.uiState.value.statusBannerMessage.orEmpty().contains("الملف غير موجود")
            )
        } finally {
            P2PTransferViewModel.resetRetainedEngineForTests()
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    private fun assertNullOrEmptyError(err: String?) {
        assertTrue("Expected no error but got: $err", err.isNullOrBlank())
    }
}

