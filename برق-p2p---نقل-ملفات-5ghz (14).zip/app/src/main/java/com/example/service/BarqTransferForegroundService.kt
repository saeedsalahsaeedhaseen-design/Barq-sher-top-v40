package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.TransferDirection
import com.example.ui.components.formatBytesArabic
import java.util.Locale

/**
 * Foreground Service that keeps P2P file transfers (Sender HTTP Server & Receiver Downloader)
 * alive when the user turns off the screen (Power button) or switches to another app.
 *
 * Holds a scoped PARTIAL_WAKE_LOCK and WifiLock ONLY while a transfer or active send session
 * is running, and releases both immediately upon completion, cancellation, or error.
 */
class BarqTransferForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_OR_UPDATE
        when (action) {
            ACTION_STOP -> {
                releaseLocks()
                isServiceActive = false
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Exception) {
                }
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE_RESUME -> {
                onPauseResumeRequested?.invoke()
                return START_STICKY
            }
            ACTION_CANCEL -> {
                onCancelRequested?.invoke()
                releaseLocks()
                isServiceActive = false
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Exception) {
                }
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_OR_UPDATE -> {
                val title = intent?.getStringExtra(EXTRA_TITLE) ?: "⚡ برق P2P • نقل مباشر بالخلفية"
                val body = intent?.getStringExtra(EXTRA_BODY) ?: "جاري نقل الملفات..."
                val subText = intent?.getStringExtra(EXTRA_SUBTEXT) ?: ""
                val progressPermille = intent?.getIntExtra(EXTRA_PROGRESS_PERMILLE, 0) ?: 0
                val indeterminate = intent?.getBooleanExtra(EXTRA_INDETERMINATE, false) ?: false
                val isPaused = intent?.getBooleanExtra(EXTRA_IS_PAUSED, false) ?: false

                acquireLocksIfNeeded()
                isServiceActive = true
                lastNotificationTitle = title
                lastNotificationBody = body
                lastProgressPermille = progressPermille

                val notification = buildTransferNotification(
                    context = this,
                    title = title,
                    body = body,
                    subText = subText,
                    progressPermille = progressPermille,
                    indeterminate = indeterminate,
                    isPaused = isPaused
                )

                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(
                            NOTIFICATION_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, notification)
                    }
                } catch (_: Exception) {
                    // Fallback to NotificationManager update if startForeground is restricted
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    nm?.notify(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    private fun acquireLocksIfNeeded() {
        try {
            if (wakeLock == null) {
                val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "BarqSher:TransferWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                // Max 3-hour safety timeout for multi-GB transfers so battery is never drained forever
                wakeLock?.acquire(3 * 60 * 60 * 1000L)
            }
            isWakeLockHeld = wakeLock?.isHeld == true
        } catch (_: Exception) {
        }

        try {
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm?.createWifiLock(lockMode, "BarqSher:TransferWifiLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
            isWifiLockHeld = wifiLock?.isHeld == true
        } catch (_: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        } finally {
            isWakeLockHeld = false
        }

        try {
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
        } catch (_: Exception) {
        } finally {
            isWifiLockHeld = false
        }
    }

    override fun onDestroy() {
        releaseLocks()
        isServiceActive = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "barq_p2p_transfer_channel"
        const val NOTIFICATION_ID = 8989

        const val ACTION_START_OR_UPDATE = "com.example.service.action.START_OR_UPDATE"
        const val ACTION_STOP = "com.example.service.action.STOP"
        const val ACTION_PAUSE_RESUME = "com.example.service.action.PAUSE_RESUME"
        const val ACTION_CANCEL = "com.example.service.action.CANCEL"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_BODY = "extra_body"
        const val EXTRA_SUBTEXT = "extra_subtext"
        const val EXTRA_PROGRESS_PERMILLE = "extra_progress_permille"
        const val EXTRA_INDETERMINATE = "extra_indeterminate"
        const val EXTRA_IS_PAUSED = "extra_is_paused"
        const val EXTRA_OPEN_LIVE_TRANSFER = "extra_open_live_transfer"

        @Volatile
        var isServiceActive: Boolean = false
            private set

        @Volatile
        var isWakeLockHeld: Boolean = false
            private set

        @Volatile
        var isWifiLockHeld: Boolean = false
            private set

        @Volatile
        var lastNotificationTitle: String = ""
            private set

        @Volatile
        var lastNotificationBody: String = ""
            private set

        @Volatile
        var lastProgressPermille: Int = 0
            private set

        @Volatile
        private var lastUpdateTimestampMs: Long = 0L

        var onPauseResumeRequested: (() -> Unit)? = null
        var onCancelRequested: (() -> Unit)? = null

        fun ensureNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    ?: return
                val existing = nm.getNotificationChannel(CHANNEL_ID)
                if (existing == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "نقل الملفات المباشر (برق P2P)",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "يحافظ على استمرار إرسال واستلام الملفات الكبيرة عند إطفاء الشاشة أو مغادرة التطبيق"
                        setShowBadge(false)
                    }
                    nm.createNotificationChannel(channel)
                }
            }
        }

        fun buildTransferNotification(
            context: Context,
            title: String,
            body: String,
            subText: String,
            progressPermille: Int,
            indeterminate: Boolean,
            isPaused: Boolean
        ): Notification {
            ensureNotificationChannel(context)

            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_LIVE_TRANSFER, true)
            }
            val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            val contentPendingIntent = PendingIntent.getActivity(
                context,
                1001,
                openAppIntent,
                pendingFlags
            )

            val pauseResumeIntent = Intent(context, BarqTransferForegroundService::class.java).apply {
                action = ACTION_PAUSE_RESUME
            }
            val pauseResumePending = PendingIntent.getService(
                context,
                1002,
                pauseResumeIntent,
                pendingFlags
            )

            val cancelIntent = Intent(context, BarqTransferForegroundService::class.java).apply {
                action = ACTION_CANCEL
            }
            val cancelPending = PendingIntent.getService(
                context,
                1003,
                cancelIntent,
                pendingFlags
            )

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(body)
                .setSubText(subText.ifBlank { null })
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(contentPendingIntent)
                .setProgress(1000, progressPermille.coerceIn(0, 1000), indeterminate)
                .addAction(
                    android.R.drawable.ic_media_pause,
                    if (isPaused) "استئناف" else "إيقاف مؤقت",
                    pauseResumePending
                )
                .addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "إلغاء",
                    cancelPending
                )
                .build()
        }

        /**
         * Starts or updates the foreground transfer service.
         * Throttles non-critical updates to at most every 400ms unless forceUpdate = true
         * so high-speed 50 MB/s transfers never flood the system NotificationManager.
         */
        fun startOrUpdateTransfer(
            context: Context,
            direction: TransferDirection,
            currentFileName: String,
            completedFiles: Int,
            totalFiles: Int,
            transferredBytes: Long,
            totalBytes: Long,
            speedBytesPerSec: Long,
            isPaused: Boolean = false,
            isStandbySession: Boolean = false,
            forceUpdate: Boolean = false
        ) {
            val now = System.currentTimeMillis()
            if (!forceUpdate && isServiceActive && (now - lastUpdateTimestampMs) < 400L) {
                return
            }
            lastUpdateTimestampMs = now

            val progressFraction = if (totalBytes > 0L) {
                (transferredBytes.toDouble() / totalBytes.toDouble()).coerceIn(0.0, 1.0)
            } else {
                0.0
            }
            val progressPermille = (progressFraction * 1000.0).toInt().coerceIn(0, 1000)
            val progressPercent = (progressFraction * 100.0).toInt().coerceIn(0, 100)

            val directionLabel = if (direction == TransferDirection.SENDING) "جاري الإرسال" else "جاري الاستلام"
            val title = when {
                isStandbySession -> "⚡ برق P2P • جلسة الإرسال نشطة بالخلفية"
                isPaused -> "⏸ برق P2P • النقل متوقف مؤقتاً ($progressPercent%)"
                else -> "⚡ برق P2P • $directionLabel ($progressPercent%)"
            }

            val speedMb = speedBytesPerSec.toDouble() / (1024.0 * 1024.0)
            val speedStr = String.format(Locale.US, "%.1f MB/s", speedMb)
            val body = if (isStandbySession) {
                "خادم النقل المباشر جاهز (${totalFiles} ملف) • يعمل حتى عند إطفاء الشاشة"
            } else {
                val activeLabel = currentFileName.ifBlank { "ملف قيد النقل" }
                "الملف: $activeLabel\n${formatBytesArabic(transferredBytes)} / ${formatBytesArabic(totalBytes)} • السرعة: $speedStr • الملفات: $completedFiles/$totalFiles"
            }
            val subText = if (totalFiles > 0) "$completedFiles / $totalFiles مكتمل" else "نشط بالخلفية"

            lastNotificationTitle = title
            lastNotificationBody = body
            lastProgressPermille = progressPermille

            val appContext = context.applicationContext
            val intent = Intent(appContext, BarqTransferForegroundService::class.java).apply {
                action = ACTION_START_OR_UPDATE
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_BODY, body)
                putExtra(EXTRA_SUBTEXT, subText)
                putExtra(EXTRA_PROGRESS_PERMILLE, progressPermille)
                putExtra(EXTRA_INDETERMINATE, isStandbySession)
                putExtra(EXTRA_IS_PAUSED, isPaused)
            }

            try {
                if (!isServiceActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(intent)
                } else {
                    appContext.startService(intent)
                }
                isServiceActive = true
            } catch (_: Exception) {
                // If OS blocks startForegroundService while already in background, still post notification directly
                try {
                    val notification = buildTransferNotification(
                        context = appContext,
                        title = title,
                        body = body,
                        subText = subText,
                        progressPermille = progressPermille,
                        indeterminate = isStandbySession,
                        isPaused = isPaused
                    )
                    val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    nm?.notify(NOTIFICATION_ID, notification)
                } catch (_: Exception) {
                }
            }
        }

        fun stopTransferService(context: Context) {
            lastUpdateTimestampMs = 0L
            isServiceActive = false
            isWakeLockHeld = false
            isWifiLockHeld = false
            val appContext = context.applicationContext
            try {
                val stopIntent = Intent(appContext, BarqTransferForegroundService::class.java).apply {
                    action = ACTION_STOP
                }
                appContext.startService(stopIntent)
            } catch (_: Exception) {
                try {
                    appContext.stopService(Intent(appContext, BarqTransferForegroundService::class.java))
                } catch (_: Exception) {
                }
            }
            try {
                val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                nm?.cancel(NOTIFICATION_ID)
            } catch (_: Exception) {
            }
        }

        fun isIgnoringBatteryOptimizations(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                pm?.isIgnoringBatteryOptimizations(context.packageName) ?: true
            } else {
                true
            }
        }
    }
}
