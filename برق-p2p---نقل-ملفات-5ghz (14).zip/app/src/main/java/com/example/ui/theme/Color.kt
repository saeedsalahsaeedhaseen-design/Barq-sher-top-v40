package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Cyber-Dark Palette for 5GHz P2P Transfer
val MidnightBg = Color(0xFF060B16)
val MidnightSurface = Color(0xFF0D1628)
val MidnightCard = Color(0xFF131F38)
val MidnightCardElevated = Color(0xFF1A2A4A)
val GlassBorder = Color(0xFF263B63)

// Accents
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDim = Color(0xFF0088A3)
val NeonEmerald = Color(0xFF10B981)
val NeonEmeraldDim = Color(0xFF056C4B)
val HotspotAmber = Color(0xFFF59E0B)
val HotspotAmberSoft = Color(0xFF3B2A10)
val CoralRose = Color(0xFFF43F5E)
val RoyalViolet = Color(0xFF8B5CF6)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
