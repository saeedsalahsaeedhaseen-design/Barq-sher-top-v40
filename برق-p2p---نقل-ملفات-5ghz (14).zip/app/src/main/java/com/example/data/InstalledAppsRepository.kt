package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.InstalledAppItem
import java.io.File

/**
 * Queries real installed applications on the device using PackageManager,
 * extracting each app's actual colored icon, label, package name, version,
 * APK file path, exact size in bytes, and split APK metadata.
 */
object InstalledAppsRepository {

    fun loadInstalledSharableApps(
        context: Context,
        includeSystemApps: Boolean = false
    ): List<InstalledAppItem> {
        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(
                    launchIntent,
                    PackageManager.ResolveInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(launchIntent, 0)
            }
        } catch (_: Exception) {
            emptyList()
        }

        val discoveredPackages = LinkedHashMap<String, ApplicationInfo>()
        for (ri in resolveInfos) {
            val appInfo = ri.activityInfo?.applicationInfo ?: continue
            discoveredPackages[appInfo.packageName] = appInfo
        }

        // Also check getInstalledApplications in case some user-installed apps lack a standard LAUNCHER activity
        try {
            val allApps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            for (appInfo in allApps) {
                if (!discoveredPackages.containsKey(appInfo.packageName)) {
                    discoveredPackages[appInfo.packageName] = appInfo
                }
            }
        } catch (_: Exception) {
        }

        val result = mutableListOf<InstalledAppItem>()
        for ((pkgName, appInfo) in discoveredPackages) {
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem && !includeSystemApps && pkgName != context.packageName) {
                continue
            }

            val apkPath = appInfo.publicSourceDir ?: appInfo.sourceDir ?: continue
            val apkFile = File(apkPath)
            if (!apkFile.exists() || !apkFile.canRead()) continue

            val label = try {
                val loaded = appInfo.loadLabel(pm).toString().trim()
                if (loaded.isNotEmpty()) loaded else pkgName
            } catch (_: Exception) {
                pkgName
            }

            val pkgInfo = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0L))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkgName, 0)
                }
            } catch (_: Exception) {
                null
            }

            val versionName = pkgInfo?.versionName ?: "1.0"
            val lastUpdated = pkgInfo?.lastUpdateTime ?: apkFile.lastModified()
            val splits = appInfo.splitPublicSourceDirs ?: appInfo.splitSourceDirs
            val splitCount = splits?.size ?: 0

            val iconBitmap = try {
                val drawable = appInfo.loadIcon(pm)
                drawableToImageBitmap(drawable, targetPx = 96)
            } catch (_: Throwable) {
                null
            }

            result.add(
                InstalledAppItem(
                    packageName = pkgName,
                    appName = label,
                    versionName = versionName,
                    apkFile = apkFile,
                    sizeBytes = apkFile.length(),
                    lastUpdatedMillis = lastUpdated,
                    isSystemApp = isSystem,
                    hasSplitApks = splitCount > 0,
                    splitCount = splitCount,
                    iconBitmap = iconBitmap
                )
            )
        }

        return result.sortedWith(
            compareBy<InstalledAppItem> { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    internal fun drawableToImageBitmap(drawable: Drawable, targetPx: Int = 96): ImageBitmap? {
        return try {
            if (drawable is BitmapDrawable && drawable.bitmap != null) {
                val b = drawable.bitmap
                if (b.width <= targetPx && b.height <= targetPx) {
                    return b.asImageBitmap()
                }
            }
            val width = if (drawable.intrinsicWidth > 0) minOf(drawable.intrinsicWidth, targetPx) else targetPx
            val height = if (drawable.intrinsicHeight > 0) minOf(drawable.intrinsicHeight, targetPx) else targetPx
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        } catch (_: Throwable) {
            null
        }
    }
}
